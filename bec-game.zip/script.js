let currentChapter = 1;
let currentLevel = 1;
let selectedCards = [];
let matchedPairs = [];
let score = 0;
let combo = 0;
let maxCombo = 0;
let totalAttempts = 0;
let correctAttempts = 0;
let gameStartTime = 0;
let currentVocab = [];
let currentStory = null;
let hintUsed = false;

// 音频上下文
let audioContext = null;

// 初始化音频上下文
function initAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
}

// 播放音效函数
function playSound(type) {
    if (!audioContext) initAudio();
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    switch(type) {
        case 'match':
            oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
            oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.1); // E5
            oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.2); // G5
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.4);
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.4);
            break;
        case 'wrong':
            oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
            oscillator.frequency.setValueAtTime(150, audioContext.currentTime + 0.1);
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.2);
            break;
        case 'combo':
            oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
            oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.08);
            oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.16);
            oscillator.frequency.setValueAtTime(1046.50, audioContext.currentTime + 0.24); // C6
            gainNode.gain.setValueAtTime(0.35, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
            break;
        case 'complete':
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5
            oscillator.frequency.setValueAtTime(659.25, audioContext.currentTime + 0.08); // E5
            oscillator.frequency.setValueAtTime(783.99, audioContext.currentTime + 0.16); // G5
            oscillator.frequency.setValueAtTime(1046.50, audioContext.currentTime + 0.24); // C6
            oscillator.frequency.setValueAtTime(1244.51, audioContext.currentTime + 0.32); // D6
            oscillator.frequency.setValueAtTime(1396.91, audioContext.currentTime + 0.4); // E6
            oscillator.frequency.setValueAtTime(1567.98, audioContext.currentTime + 0.48); // F6
            oscillator.frequency.setValueAtTime(2093.00, audioContext.currentTime + 0.56); // C7
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.setValueAtTime(0.4, audioContext.currentTime + 0.24);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1.2);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 1.2);
            break;
        case 'click':
            oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
            gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.1);
            break;
    }
}

// 创建庆祝粒子
function createCelebrationParticles() {
    const colors = ['#FF8DA1', '#B5EAD7', '#FFD1DC', '#98D8C8', '#FFD700', '#FFB6C1'];
    const emojis = ['✨', '🎉', '⭐', '💫', '🌟'];
    
    for (let i = 0; i < 30; i++) {
        setTimeout(() => {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            if (Math.random() > 0.5) {
                particle.textContent = emojis[Math.floor(Math.random() * emojis.length)];
                particle.style.fontSize = (20 + Math.random() * 20) + 'px';
            } else {
                particle.style.width = (8 + Math.random() * 12) + 'px';
                particle.style.height = particle.style.width;
                particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                particle.style.borderRadius = '50%';
            }
            
            particle.style.left = (Math.random() * window.innerWidth) + 'px';
            particle.style.top = '-50px';
            particle.style.animationDelay = (Math.random() * 0.5) + 's';
            
            document.body.appendChild(particle);
            
            setTimeout(() => {
                particle.remove();
            }, 2500);
        }, i * 100);
    }
}

// 连击庆祝效果
function createComboEffect(comboCount) {
    const comboFloat = document.getElementById('combo-float');
    
    if (comboCount >= 5) {
        createCelebrationParticles();
        playSound('complete');
    }
    
    comboFloat.innerHTML = `<span style="color: #FF8DA1; font-size: 3rem; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">${comboCount}连击！</span>`;
    comboFloat.style.display = 'block';
    
    setTimeout(() => {
        comboFloat.style.display = 'none';
        comboFloat.innerHTML = '';
    }, 1500);
}

const achievements = [
    {"id": "first_win", "title": "首次通关", "emoji": "🏆", "desc": "完成第一关", "unlocked": false},
    {"id": "combo_10", "title": "10连击", "desc": "达成10连击", "emoji": "🔥", "unlocked": false},
    {"id": "master_50", "title": "词汇达人", "desc": "累计掌握50词", "emoji": "📚", "unlocked": false},
    {"id": "speed_clear", "title": "速通高手", "desc": "60秒内清盘", "emoji": "⚡", "unlocked": false},
    {"id": "perfect", "title": "完美通关", "desc": "零失误通关", "emoji": "🎯", "unlocked": false},
    {"id": "truth", "title": "真心话", "desc": "连续5关三星通关", "emoji": "💕", "unlocked": false},
    {"id": "love_letter", "title": "告白信", "desc": "全部通关", "emoji": "💌", "unlocked": false},
    {"id": "all_stars", "title": "全三星", "desc": "所有关卡三星通关", "emoji": "👑", "unlocked": false}
];

let progress = {
    chapters: {
        1: { unlocked: true, stars: 0, completed: 0 },
        2: { unlocked: false, stars: 0, completed: 0 },
        3: { unlocked: false, stars: 0, completed: 0 }
    },
    levels: {},
    wordProgress: {},
    stats: {
        totalStars: 0,
        masteredWords: 0,
        completedLevels: 0,
        maxCombo: 0,
        totalCorrect: 0,
        totalAttempts: 0
    },
    achievements: {}
};

function loadProgress() {
    const saved = localStorage.getItem('becGameProgress');
    if (saved) {
        progress = JSON.parse(saved);
    } else {
        initProgress();
    }
    updateAchievements();
}

function initProgress() {
    for (let chapter = 1; chapter <= 3; chapter++) {
        for (let level = 1; level <= 10; level++) {
            const key = `${chapter}-${level}`;
            progress.levels[key] = progress.levels[key] || { stars: 0, completed: false, attempts: 0, correct: 0 };
        }
    }
    vocabData.forEach(word => {
        progress.wordProgress[word.word] = progress.wordProgress[word.word] || {
            status: 'unknown',
            reviews: 0,
            lastReview: null,
            interval: 1
        };
    });
    achievements.forEach(ach => {
        progress.achievements[ach.id] = progress.achievements[ach.id] || { unlocked: false, progress: 0 };
    });
}

function saveProgress() {
    localStorage.setItem('becGameProgress', JSON.stringify(progress));
}

function updateAchievements() {
    if (progress.stats.completedLevels >= 1) achievements[0].unlocked = true;
    if (progress.stats.maxCombo >= 10) achievements[1].unlocked = true;
    if (progress.stats.masteredWords >= 50) achievements[2].unlocked = true;
    
    const allCompleted = Object.keys(progress.levels).every(k => progress.levels[k].completed);
    if (allCompleted) achievements[6].unlocked = true;
    
    const allStars = Object.keys(progress.levels).every(k => progress.levels[k].stars >= 3);
    if (allStars) achievements[7].unlocked = true;
    
    achievements.forEach(ach => {
        progress.achievements[ach.id] = { unlocked: ach.unlocked };
    });
}

function getVocabById(id) {
    return vocabData.find(v => v.word === id);
}

function getStory(chapter, level) {
    return storyData.find(s => s.chapter === chapter && s.level === level);
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
}

function showHome() {
    updateHomeStats();
    showPage('home-page');
}

function showChapterSelect() {
    showPage('chapter-select');
}

function showLevelMap(chapter) {
    currentChapter = chapter;
    document.getElementById('chapter-title').textContent = getChapterTitle(chapter);
    renderLevelGrid(chapter);
    showPage('level-map');
}

function getChapterTitle(chapter) {
    const titles = {
        1: '第一章：入职风暴',
        2: '第二章：商战暗涌',
        3: '第三章：巅峰对决'
    };
    return titles[chapter];
}

function renderLevelGrid(chapter) {
    const grid = document.getElementById('level-grid');
    grid.innerHTML = '';
    
    for (let level = 1; level <= 10; level++) {
        const key = `${chapter}-${level}`;
        const levelData = progress.levels[key];
        const isUnlocked = isLevelUnlocked(chapter, level);
        const isCurrent = chapter === currentChapter && level === currentLevel;
        
        const item = document.createElement('div');
        item.className = `level-item ${isUnlocked ? 'unlocked' : 'locked'} ${isCurrent ? 'current' : ''}`;
        item.innerHTML = `
            <span class="level-number">${level}</span>
            <span class="level-stars">${getStarsDisplay(levelData?.stars || 0)}</span>
        `;
        
        if (isUnlocked) {
            item.onclick = () => startLevel(chapter, level);
        }
        grid.appendChild(item);
    }
}

function isLevelUnlocked(chapter, level) {
    if (chapter === 1 && level === 1) return true;
    const prevKey = level > 1 ? `${chapter}-${level - 1}` : `${chapter - 1}-10`;
    return progress.levels[prevKey]?.completed || false;
}

function getStarsDisplay(count) {
    return '★'.repeat(count) + '☆'.repeat(3 - count);
}

function startLevel(chapter, level) {
    currentChapter = chapter;
    currentLevel = level;
    currentStory = getStory(chapter, level);
    showPreStory();
}

function showPreStory() {
    const chatArea = document.getElementById('chat-area');
    chatArea.innerHTML = '';
    document.getElementById('story-title').textContent = currentStory.title;
    document.querySelector('.story-level').textContent = `第 ${currentChapter}章 · 第 ${currentLevel}关`;
    
    showPage('story-page');
    displayStoryLine(currentStory.pre_story, 0);
}

function displayStoryLine(lines, index) {
    if (index >= lines.length) return;
    
    const line = lines[index];
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${line.speaker === 'narrator' ? 'narrator' : line.speaker === 'lujingchen' ? 'left' : 'right'}`;
    
    const text = formatStoryText(line.text);
    bubble.innerHTML = line.speaker === 'narrator' 
        ? `<span class="chat-text">${text}</span>`
        : `
            <span class="speaker-name">${line.speaker === 'lujingchen' ? '陆景琛' : '你'}</span>
            <span class="chat-text">${text}</span>
        `;
    
    document.getElementById('chat-area').appendChild(bubble);
    bubble.scrollIntoView({ behavior: 'smooth' });
    
    setTimeout(() => displayStoryLine(lines, index + 1), 1500);
}

function formatStoryText(text) {
    return text.replace(/<vocab>([^<]+)<\/vocab>/g, '<span class="vocab-highlight" onclick="showVocabModal(\'$1\')">$1</span>');
}

function continueStory() {
    const chatArea = document.getElementById('chat-area');
    if (chatArea.children.length >= currentStory.pre_story.length) {
        startGame();
    }
}

function skipStory() {
    startGame();
}

function startGame() {
    initGame();
    renderGameBoard();
    showPage('game-page');
}

function initGame() {
    selectedCards = [];
    matchedPairs = [];
    score = 0;
    combo = 0;
    maxCombo = 0;
    totalAttempts = 0;
    correctAttempts = 0;
    hintUsed = false;
    gameStartTime = Date.now();
    
    const vocabIds = currentStory.vocab_ids;
    currentVocab = vocabIds.map(id => getVocabById(id)).filter(Boolean);
    
    updateScore();
    updateCombo();
    updateFeedback('准备好了吗？开始匹配单词吧。', '😐');
}

function renderGameBoard() {
    const board = document.getElementById('game-board');
    board.innerHTML = '';
    
    const cards = [];
    currentVocab.forEach(vocab => {
        cards.push({ type: 'word', content: vocab.word, vocab: vocab });
        cards.push({ type: 'meaning', content: vocab.meaning, vocab: vocab });
    });
    
    shuffleArray(cards);
    
    cards.forEach((card, index) => {
        const element = document.createElement('div');
        element.className = `card type-${card.type}`;
        element.dataset.index = index;
        
        element.innerHTML = `
            <span class="card-main">${card.content}</span>
        `;
        
        element.onclick = () => selectCard(card, element);
        board.appendChild(element);
    });
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

function selectCard(card, element) {
    if (element.classList.contains('matched') || element.classList.contains('selected')) return;
    
    playSound('click');
    element.classList.add('selected');
    selectedCards.push({ card, element });
    
    if (selectedCards.length === 2) {
        checkMatch();
    }
}

function checkMatch() {
    totalAttempts++;
    
    const cards = selectedCards.map(s => s.card);
    const vocabIds = [...new Set(cards.map(c => c.vocab.word))];
    
    if (vocabIds.length === 1) {
        handleMatch();
    } else {
        handleMismatch();
    }
}

function handleMatch() {
    correctAttempts++;
    combo++;
    if (combo > maxCombo) maxCombo = combo;
    
    const vocab = selectedCards[0].card.vocab;
    matchedPairs.push(vocab);
    
    updateWordProgress(vocab.word, true);
    
    const comboBonus = Math.floor(combo / 3) * 10;
    score += 100 + comboBonus;
    
    updateScore();
    updateCombo();
    updateFeedback(`匹配成功！+${100 + comboBonus}分`, '😊');
    
    if (combo >= 5) {
        createComboEffect(combo);
    } else if (combo >= 3) {
        playSound('combo');
        showComboAnimation(vocab.emoji);
    } else {
        playSound('match');
    }
    
    selectedCards.forEach(s => {
        s.element.classList.add('matched');
        s.element.classList.remove('selected');
    });
    
    selectedCards = [];
    
    if (matchedPairs.length >= currentVocab.length) {
        playSound('complete');
        createCelebrationParticles();
        setTimeout(showResult, 800);
    }
}

function handleMismatch() {
    combo = 0;
    playSound('wrong');
    
    updateCombo();
    updateFeedback('匹配错误，再试试。', '😐');
    
    selectedCards.forEach(s => {
        s.element.classList.add('wrong');
        setTimeout(() => {
            s.element.classList.remove('wrong', 'selected');
        }, 500);
    });
    
    selectedCards = [];
}

function showComboAnimation(emoji) {
    const float = document.getElementById('combo-float');
    float.innerHTML = emoji.repeat(combo);
    float.style.display = 'block';
    
    setTimeout(() => {
        float.style.display = 'none';
        float.innerHTML = '';
    }, 1000);
}

function updateScore() {
    document.getElementById('score').textContent = score;
}

function updateCombo() {
    const display = document.getElementById('combo-display');
    if (combo >= 2) {
        display.innerHTML = `<span class="combo-text">${combo}连击！</span>`;
    } else {
        display.innerHTML = '';
    }
}

function updateFeedback(text, face) {
    document.getElementById('ceo-face').textContent = face;
    document.getElementById('feedback-text').textContent = text;
}

function useHint() {
    if (hintUsed) {
        updateFeedback('提示只能使用一次。', '😐');
        return;
    }
    
    hintUsed = true;
    const unmatchedCards = document.querySelectorAll('.card:not(.matched)');
    if (unmatchedCards.length > 0) {
        const randomCard = unmatchedCards[Math.floor(Math.random() * unmatchedCards.length)];
        randomCard.style.borderColor = '#f5d061';
        randomCard.style.boxShadow = '0 0 20px rgba(245, 208, 97, 0.6)';
        
        updateFeedback("I'll give you a hint. Just this once.", '😐');
        
        setTimeout(() => {
            randomCard.style.borderColor = '';
            randomCard.style.boxShadow = '';
        }, 2000);
    }
}

function updateWordProgress(word, correct) {
    const progressData = progress.wordProgress[word];
    if (!progressData) return;
    
    progressData.reviews++;
    progressData.lastReview = Date.now();
    
    if (correct) {
        switch (progressData.status) {
            case 'unknown': progressData.status = 'fuzzy'; break;
            case 'fuzzy': progressData.status = 'familiar'; break;
            case 'familiar': progressData.status = 'mastered'; break;
        }
    } else {
        if (progressData.status !== 'unknown') {
            progressData.status = 'fuzzy';
        }
    }
    
    if (progressData.status === 'mastered') {
        progress.stats.masteredWords = Object.values(progress.wordProgress).filter(w => w.status === 'mastered').length;
    }
}

function showResult() {
    const timeUsed = Math.floor((Date.now() - gameStartTime) / 1000);
    const accuracy = totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 100;
    const isPerfect = totalAttempts === correctAttempts;
    const isSpeed = timeUsed <= 60;
    
    let stars = 3;
    if (accuracy < 60) stars = 1;
    else if (accuracy < 80) stars = 2;
    
    if (isPerfect) achievements[4].unlocked = true;
    if (isSpeed) achievements[3].unlocked = true;
    
    const key = `${currentChapter}-${currentLevel}`;
    const levelProgress = progress.levels[key];
    if (stars > levelProgress.stars) {
        levelProgress.stars = stars;
    }
    levelProgress.completed = true;
    levelProgress.attempts += totalAttempts;
    levelProgress.correct += correctAttempts;
    
    progress.stats.totalStars += stars;
    progress.stats.completedLevels++;
    progress.stats.maxCombo = Math.max(progress.stats.maxCombo, maxCombo);
    progress.stats.totalAttempts += totalAttempts;
    progress.stats.totalCorrect += correctAttempts;
    
    if (currentLevel === 10) {
        progress.chapters[currentChapter].completed = true;
        progress.chapters[currentChapter].stars += stars;
        if (currentChapter < 3) {
            progress.chapters[currentChapter + 1].unlocked = true;
        }
    }
    
    updateAchievements();
    saveProgress();
    
    document.getElementById('final-score').textContent = score;
    document.getElementById('accuracy').textContent = `${accuracy}%`;
    document.getElementById('time-used').textContent = `${timeUsed}秒`;
    document.getElementById('new-words').textContent = currentVocab.length;
    
    renderStars(stars);
    renderResultStory(stars);
    renderNewWords();
    
    showPage('result-page');
}

function renderStars(count) {
    const container = document.getElementById('stars-container');
    container.innerHTML = '';
    
    for (let i = 0; i < 3; i++) {
        const star = document.createElement('span');
        star.className = `star ${i < count ? 'active' : ''}`;
        star.textContent = '★';
        star.style.animationDelay = `${i * 0.2}s`;
        container.appendChild(star);
    }
}

function renderResultStory(stars) {
    const storyArea = document.getElementById('result-story');
    storyArea.innerHTML = '';
    
    let storyKey = `post_story_stars${stars}`;
    if (!currentStory[storyKey] || currentStory[storyKey].length === 0) {
        storyKey = 'post_story_stars2';
    }
    
    currentStory[storyKey].forEach(line => {
        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${line.speaker === 'lujingchen' ? 'left' : 'right'}`;
        const text = formatStoryText(line.text);
        bubble.innerHTML = `
            <span class="speaker-name">${line.speaker === 'lujingchen' ? '陆景琛' : '你'}</span>
            <span class="chat-text">${text}</span>
        `;
        storyArea.appendChild(bubble);
    });
}

function renderNewWords() {
    const grid = document.querySelector('.new-words-list .words-grid');
    grid.innerHTML = '';
    
    currentVocab.forEach(vocab => {
        const card = document.createElement('div');
        card.className = 'word-card';
        card.innerHTML = `
            <div class="word-card-emoji">${vocab.emoji}</div>
            <div class="word-card-word">${vocab.word}</div>
            <div class="word-card-meaning">${vocab.meaning}</div>
        `;
        card.onclick = () => showVocabModal(vocab.word);
        grid.appendChild(card);
    });
}

function showVocabModal(word) {
    const vocab = getVocabById(word);
    if (!vocab) return;
    
    document.getElementById('vocab-emoji').textContent = vocab.emoji;
    document.getElementById('vocab-word').textContent = vocab.word;
    document.getElementById('vocab-phonetic').textContent = vocab.phonetic;
    document.getElementById('vocab-pos').textContent = vocab.pos;
    document.getElementById('vocab-meaning').textContent = vocab.meaning;
    document.getElementById('vocab-category').textContent = `分类: ${vocab.category}`;
    
    document.getElementById('vocab-modal').classList.add('active');
}

function closeVocabModal() {
    document.getElementById('vocab-modal').classList.remove('active');
}

function replayLevel() {
    startLevel(currentChapter, currentLevel);
}

function nextLevel() {
    let nextLevelNum = currentLevel + 1;
    let nextChapterNum = currentChapter;
    
    if (nextLevelNum > 10) {
        nextLevelNum = 1;
        nextChapterNum++;
    }
    
    if (nextChapterNum > 3) {
        showHome();
    } else {
        startLevel(nextChapterNum, nextLevelNum);
    }
}

function showWordBook() {
    renderWordList('all');
    showPage('wordbook-page');
}

function renderWordList(filter) {
    const list = document.getElementById('word-list');
    list.innerHTML = '';
    
    const words = Object.entries(progress.wordProgress).map(([word, data]) => {
        const vocab = getVocabById(word);
        return { ...vocab, ...data };
    }).filter(w => w.word);
    
    let filtered = words;
    if (filter !== 'all') {
        filtered = words.filter(w => w.status === filter);
    }
    
    const searchTerm = document.getElementById('word-search')?.value.toLowerCase() || '';
    if (searchTerm) {
        filtered = filtered.filter(w => 
            w.word.toLowerCase().includes(searchTerm) || 
            w.meaning.includes(searchTerm)
        );
    }
    
    filtered.forEach(item => {
        const element = document.createElement('div');
        element.className = 'wordbook-item';
        element.innerHTML = `
            <div class="wordbook-emoji">${item.emoji}</div>
            <div class="wordbook-info">
                <div class="wordbook-word">${item.word}</div>
                <div class="wordbook-meaning">${item.meaning}</div>
            </div>
            <span class="wordbook-status ${item.status}">${getStatusText(item.status)}</span>
        `;
        element.onclick = () => showVocabModal(item.word);
        list.appendChild(element);
    });
}

function getStatusText(status) {
    const texts = {
        unknown: '陌生',
        fuzzy: '模糊',
        familiar: '熟悉',
        mastered: '掌握'
    };
    return texts[status] || status;
}

function filterWords() {
    const activeFilter = document.querySelector('.filter-btn.active')?.dataset.filter || 'all';
    renderWordList(activeFilter);
}

function showAchievements() {
    const grid = document.getElementById('achievements-grid');
    grid.innerHTML = '';
    
    achievements.forEach(ach => {
        const card = document.createElement('div');
        card.className = `achievement-card ${ach.unlocked ? 'unlocked' : 'locked'}`;
        card.innerHTML = `
            <div class="achievement-emoji">${ach.unlocked ? ach.emoji : '🔒'}</div>
            <div class="achievement-title">${ach.title}</div>
            <div class="achievement-desc">${ach.desc}</div>
        `;
        grid.appendChild(card);
    });
    
    showPage('achievements-page');
}

function updateHomeStats() {
    document.querySelector('.progress-stats .stat-item:nth-child(1) .stat-value').textContent = progress.stats.totalStars;
    document.querySelector('.progress-stats .stat-item:nth-child(2) .stat-value').textContent = progress.stats.masteredWords;
    document.querySelector('.progress-stats .stat-item:nth-child(3) .stat-value').textContent = progress.stats.completedLevels;
}

document.addEventListener('DOMContentLoaded', () => {
    loadProgress();
    updateHomeStats();
    
    document.querySelectorAll('.chapter-card').forEach(card => {
        card.onclick = () => {
            const chapter = parseInt(card.dataset.chapter);
            if (progress.chapters[chapter].unlocked) {
                showLevelMap(chapter);
            }
        };
    });
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderWordList(btn.dataset.filter);
        };
    });
});
