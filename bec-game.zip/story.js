const storyData = [
    {
        "chapter": 1,
        "level": 1,
        "title": "第一天报到",
        "pre_story": [
            {"speaker": "narrator", "text": "你怀着紧张又兴奋的心情，走进了寰宇集团总部大楼..."},
            {"speaker": "lujingchen", "text": "Welcome aboard. Don't disappoint me."},
            {"speaker": "narrator", "text": "你抬头看向声音的来源——一个穿着定制西装的男人站在那里，气场强大得让人不敢直视。"},
            {"speaker": "lujingchen", "text": "Your <vocab>schedule</vocab> is on your desk. The morning <vocab>meeting</vocab> starts in 15 minutes. Be prepared."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Impressive. You're quicker than I thought. The <vocab>meeting</vocab> notes were... acceptable."},
            {"speaker": "lujingchen", "text": "Keep this up and you might actually survive here. 🖊️"}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Not bad for your first day. You got most of the <vocab>agenda</vocab> right."},
            {"speaker": "lujingchen", "text": "But don't get complacent. This is just the beginning."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "Your first day was... underwhelming. The <vocab>schedule</vocab> was a mess."},
            {"speaker": "lujingchen", "text": "Study the <vocab>agenda</vocab> properly. I don't have time for mistakes."}
        ],
        "vocab_ids": ["meeting", "agenda", "schedule", "memo", "report"]
    },
    {
        "chapter": 1,
        "level": 2,
        "title": "咖啡风波",
        "pre_story": [
            {"speaker": "narrator", "text": "主管让你给CEO送杯咖啡，这是你第一次单独面对陆景琛..."},
            {"speaker": "lujingchen", "text": "...(抬头看了你一眼，眼神冰冷)"},
            {"speaker": "lujingchen", "text": "This is not what I ordered. Attention to detail is essential."},
            {"speaker": "narrator", "text": "你紧张地道歉，他却只是挥手示意你离开。"},
            {"speaker": "lujingchen", "text": "And next time, make sure the <vocab>invoice</vocab> is correct. We don't pay for mistakes."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Hmm. You learned fast. The <vocab>order</vocab> was perfect this time."},
            {"speaker": "lujingchen", "text": "Maybe you're not completely useless. ☕"}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Better. The <vocab>delivery</vocab> was on time."},
            {"speaker": "lujingchen", "text": "But the <vocab>invoice</vocab> still needs work."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "Still making mistakes? The <vocab>order</vocab> was wrong again."},
            {"speaker": "lujingchen", "text": "Pay attention to the details. They matter."}
        ],
        "vocab_ids": ["invoice", "order", "delivery", "receipt", "payment"]
    },
    {
        "chapter": 1,
        "level": 3,
        "title": "会议室危机",
        "pre_story": [
            {"speaker": "narrator", "text": "你被意外叫进了高层会议室，完全不知所措..."},
            {"speaker": "lujingchen", "text": "So, you're sitting in on the <vocab>meeting</vocab> today."},
            {"speaker": "lujingchen", "text": "The <vocab>agenda</vocab> is full. Try to keep up."},
            {"speaker": "narrator", "text": "会议内容远超你的理解范围，你拼命做着笔记。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Impressive. You understood every <vocab>proposal</vocab> on the <vocab>agenda</vocab>."},
            {"speaker": "lujingchen", "text": "Maybe you do belong here."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Not bad. You caught most of the <vocab>budget</vocab> discussion."},
            {"speaker": "lujingchen", "text": "Room for improvement, but acceptable."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "The <vocab>meeting</vocab> was clearly over your head."},
            {"speaker": "lujingchen", "text": "Study harder. I won't slow down for anyone."}
        ],
        "vocab_ids": ["meeting", "agenda", "proposal", "budget", "strategy"]
    },
    {
        "chapter": 1,
        "level": 4,
        "title": "第一次任务",
        "pre_story": [
            {"speaker": "narrator", "text": "陆景琛亲自给你布置了第一个正式任务..."},
            {"speaker": "lujingchen", "text": "I need you to organize the client data. Make it presentable."},
            {"speaker": "lujingchen", "text": "The <vocab>brochure</vocab> and <vocab>catalogue</vocab> should be included."},
            {"speaker": "narrator", "text": "你熬夜完成了任务，忐忑地等待着评价。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Excellent work. The <vocab>client</vocab> data is perfectly organized."},
            {"speaker": "lujingchen", "text": "You've exceeded my expectations... for now."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Acceptable. The <vocab>brochure</vocab> layout is clean."},
            {"speaker": "lujingchen", "text": "But the <vocab>catalogue</vocab> needs more details."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "This is sloppy. The <vocab>client</vocab> information is incomplete."},
            {"speaker": "lujingchen", "text": "Fix it. And do better next time."}
        ],
        "vocab_ids": ["client", "brochure", "catalogue", "product", "service"]
    },
    {
        "chapter": 1,
        "level": 5,
        "title": "部门暗战",
        "pre_story": [
            {"speaker": "narrator", "text": "你无意中听到同事在背后说你坏话..."},
            {"speaker": "narrator", "text": "就在这时，陆景琛出现在你身后。"},
            {"speaker": "lujingchen", "text": "Office politics. Learn to navigate."},
            {"speaker": "lujingchen", "text": "Your <vocab>colleague</vocab> is threatened by you. That's a compliment."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You handled it well. Showing your <vocab>competitor</vocab> who's boss."},
            {"speaker": "lujingchen", "text": "I like that fire in you."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You survived the first round. Good."},
            {"speaker": "lujingchen", "text": "But don't let your <vocab>rival</vocab> get the better of you."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You're too soft. This is a battlefield."},
            {"speaker": "lujingchen", "text": "Your <vocab>colleague</vocab> will eat you alive if you don't fight back."}
        ],
        "vocab_ids": ["colleague", "competitor", "rival", "teamwork", "collaboration"]
    },
    {
        "chapter": 1,
        "level": 6,
        "title": "加班之夜",
        "pre_story": [
            {"speaker": "narrator", "text": "深夜，办公室只剩下你和陆景琛..."},
            {"speaker": "lujingchen", "text": "(抬头看了你一眼) Still here?"},
            {"speaker": "narrator", "text": "你点点头，继续工作。"},
            {"speaker": "lujingchen", "text": "Even the CEO works <vocab>overtime</vocab>. Deadlines wait for no one."},
            {"speaker": "lujingchen", "text": "(递来一杯咖啡) Black. No sugar."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You have dedication. That's rare."},
            {"speaker": "lujingchen", "text": "The <vocab>deadline</vocab> was met with time to spare. ☕"}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You finished on time. That's all that matters."},
            {"speaker": "lujingchen", "text": "Learn to manage your <vocab>shift</vocab> better next time."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "Cutting it close. The <vocab>deadline</vocab> is non-negotiable."},
            {"speaker": "lujingchen", "text": "You need to work smarter, not just harder."}
        ],
        "vocab_ids": ["overtime", "deadline", "shift", "schedule", "progress"]
    },
    {
        "chapter": 1,
        "level": 7,
        "title": "突发危机",
        "pre_story": [
            {"speaker": "narrator", "text": "公司系统突然崩溃，整个办公室陷入混乱..."},
            {"speaker": "lujingchen", "text": "Quiet! Everyone listen."},
            {"speaker": "lujingchen", "text": "I need someone to contact our <vocab>supplier</vocab> immediately."},
            {"speaker": "lujingchen", "text": "(目光落在你身上) You. Do it. Don't panic. Execute."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Crisis averted. Your quick thinking saved us."},
            {"speaker": "lujingchen", "text": "The <vocab>logistics</vocab> team is impressed."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You got the job done. The <vocab>supplier</vocab> responded quickly."},
            {"speaker": "lujingchen", "text": "But the <vocab>warehouse</vocab> communication was slow."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You survived, but just barely."},
            {"speaker": "lujingchen", "text": "The <vocab>logistics</vocab> chain almost broke. Be prepared next time."}
        ],
        "vocab_ids": ["supplier", "warehouse", "logistics", "delivery", "stock"]
    },
    {
        "chapter": 1,
        "level": 8,
        "title": "露营团建",
        "pre_story": [
            {"speaker": "narrator", "text": "公司组织团建露营，没想到陆景琛也来了..."},
            {"speaker": "narrator", "text": "篝火旁，他难得地放松下来。"},
            {"speaker": "lujingchen", "text": "...(看着火焰，语气难得柔和)"},
            {"speaker": "lujingchen", "text": "Teamwork isn't just about meetings and <vocab>deadlines</vocab>."},
            {"speaker": "lujingchen", "text": "It's about trusting the people around you."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You showed real <vocab>teamwork</vocab> today."},
            {"speaker": "lujingchen", "text": "The team respects you. That's important."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You participated. That's a start."},
            {"speaker": "lujingchen", "text": "Work on your <vocab>motivation</vocab> skills."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You were... there. That's something."},
            {"speaker": "lujingchen", "text": "Learn to engage. <vocab>Teamwork</vocab> requires effort."}
        ],
        "vocab_ids": ["teamwork", "motivation", "welfare", "culture", "morale"]
    },
    {
        "chapter": 1,
        "level": 9,
        "title": "背锅事件",
        "pre_story": [
            {"speaker": "narrator", "text": "你被同事诬陷泄露商业机密，面临开除危机..."},
            {"speaker": "narrator", "text": "就在你绝望的时候，陆景琛出现了。"},
            {"speaker": "lujingchen", "text": "Enough. I've reviewed the evidence."},
            {"speaker": "lujingchen", "text": "The <vocab>confidentiality</vocab> breach wasn't her. It was you."},
            {"speaker": "lujingchen", "text": "(转向你) I trust my judgment. And my judgment says you're innocent."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You stayed calm under pressure. That's rare."},
            {"speaker": "lujingchen", "text": "The <vocab>contract</vocab> incident is closed. You're cleared."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You were vindicated. Good."},
            {"speaker": "lujingchen", "text": "But remember to read the <vocab>clause</vocab> carefully next time."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You survived, but you need to be more careful."},
            {"speaker": "lujingchen", "text": "<vocab>Confidentiality</vocab> is not a suggestion. It's a requirement."}
        ],
        "vocab_ids": ["contract", "clause", "confidentiality", "agreement", "terms"]
    },
    {
        "chapter": 1,
        "level": 10,
        "title": "年度考核",
        "pre_story": [
            {"speaker": "narrator", "text": "年度考核到了，你紧张地走进陆景琛的办公室..."},
            {"speaker": "lujingchen", "text": "Take a seat. Let's review your <vocab>performance</vocab>."},
            {"speaker": "lujingchen", "text": "(翻阅文件) You've been here six months. Progress has been... notable."},
            {"speaker": "narrator", "text": "你屏住呼吸，等待最终评价。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Your <vocab>appraisal</vocab> is excellent. Outstanding work."},
            {"speaker": "lujingchen", "text": "You've exceeded my expectations... for now."},
            {"speaker": "lujingchen", "text": "(嘴角微微上扬) And yes, you're getting that <vocab>promotion</vocab>."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Your <vocab>performance</vocab> is solid. Good progress."},
            {"speaker": "lujingchen", "text": "The <vocab>appraisal</vocab> reflects your hard work."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "Your <vocab>performance</vocab> is... acceptable."},
            {"speaker": "lujingchen", "text": "The <vocab>appraisal</vocab> shows room for improvement. Don't slack off."}
        ],
        "vocab_ids": ["appraisal", "performance", "promotion", "target", "milestone"]
    },
    {
        "chapter": 2,
        "level": 11,
        "title": "竞争对手",
        "pre_story": [
            {"speaker": "narrator", "text": "永盛集团突然发起恶意收购，公司陷入危机..."},
            {"speaker": "lujingchen", "text": "A hostile <vocab>takeover</vocab>? Interesting."},
            {"speaker": "lujingchen", "text": "They think they can take what's mine? They're mistaken."},
            {"speaker": "lujingchen", "text": "We need to prepare. An <vocab>acquisition</vocab> defense is our priority."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Your analysis was spot on. The <vocab>merger</vocab> defense plan is solid."},
            {"speaker": "lujingchen", "text": "You're proving to be an asset in this war."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Good work on the <vocab>acquisition</vocab> research."},
            {"speaker": "lujingchen", "text": "But the <vocab>takeover</vocab> defense needs more depth."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "Your report is incomplete. The <vocab>merger</vocab> details are missing."},
            {"speaker": "lujingchen", "text": "Get me the full picture. We don't have time for half-baked work."}
        ],
        "vocab_ids": ["acquisition", "merger", "takeover", "competitor", "rival"]
    },
    {
        "chapter": 2,
        "level": 12,
        "title": "谈判桌",
        "pre_story": [
            {"speaker": "narrator", "text": "你第一次陪同陆景琛出席重要谈判..."},
            {"speaker": "lujingchen", "text": "(低声) Remember: listen more than you speak."},
            {"speaker": "lujingchen", "text": "This is how business is done. Watch and learn."},
            {"speaker": "narrator", "text": "谈判开始，陆景琛的气场震撼全场。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You held your own at the table. Impressive."},
            {"speaker": "lujingchen", "text": "Your <vocab>negotiate</vocate> skills are developing nicely."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You didn't embarrass yourself. That's something."},
            {"speaker": "lujingchen", "text": "Learn to <vocab>bargain</vocab> more effectively next time."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You need to be more assertive."},
            {"speaker": "lujingchen", "text": "A <vocab>compromise</vocab> is not a surrender. Know the difference."}
        ],
        "vocab_ids": ["negotiate", "bargain", "compromise", "agreement", "terms"]
    },
    {
        "chapter": 2,
        "level": 13,
        "title": "财务暗流",
        "pre_story": [
            {"speaker": "narrator", "text": "你发现财务数据异常，犹豫是否要上报..."},
            {"speaker": "lujingchen", "text": "(注意到你的表情) Something's wrong."},
            {"speaker": "narrator", "text": "你鼓起勇气说出了发现。"},
            {"speaker": "lujingchen", "text": "Interesting. Very interesting."},
            {"speaker": "lujingchen", "text": "I need you to investigate this secretly. Trust no one but me."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You uncovered a major <vocab>audit</vocab> issue. Well done."},
            {"speaker": "lujingchen", "text": "The <vocab>deficit</vocab> would have gone unnoticed without you."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "Good catch. The <vocab>profit margin</vocab> discrepancy is noted."},
            {"speaker": "lujingchen", "text": "But you need to dig deeper next time."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You found something, but not enough."},
            {"speaker": "lujingchen", "text": "The <vocab>audit</vocab> requires more thorough investigation."}
        ],
        "vocab_ids": ["audit", "deficit", "profit margin", "revenue", "expenditure"]
    },
    {
        "chapter": 2,
        "level": 14,
        "title": "危机公关",
        "pre_story": [
            {"speaker": "narrator", "text": "负面新闻突然爆发，公司陷入舆论危机..."},
            {"speaker": "lujingchen", "text": "This is your real test. Handle this <vocab>campaign</vocab>."},
            {"speaker": "lujingchen", "text": "Our <vocab>brand</vocab> reputation is on the line."},
            {"speaker": "narrator", "text": "你临危受命，负责危机公关应对。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>publicity</vocab> crisis was handled masterfully."},
            {"speaker": "lujingchen", "text": "Our <vocab>brand</vocab> stronger than before."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You managed to contain the damage. Good."},
            {"speaker": "lujingchen", "text": "The <vocab>campaign</vocab> response was adequate."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "The damage was contained, but barely."},
            {"speaker": "lujingchen", "text": "Our <vocab>brand</vocab> took a hit. Learn from this."}
        ],
        "vocab_ids": ["campaign", "brand", "publicity", "advertisement", "media"]
    },
    {
        "chapter": 2,
        "level": 15,
        "title": "深夜密谈",
        "pre_story": [
            {"speaker": "narrator", "text": "陆景琛深夜约你单独见面，气氛异常凝重..."},
            {"speaker": "lujingchen", "text": "I need to tell you something. Off the record."},
            {"speaker": "lujingchen", "text": "The <vocab>venture capital</vocab> deal is more important than it seems."},
            {"speaker": "lujingchen", "text": "I'm staking everything on this <vocab>ROI</vocab>."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You understand the stakes. That's why I trust you."},
            {"speaker": "lujingchen", "text": "The <vocab>equity</vocab> arrangement is in place."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You grasp the basics. Good."},
            {"speaker": "lujingchen", "text": "Study <vocab>investment</vocab> strategies more deeply."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You're getting there, but slowly."},
            {"speaker": "lujingchen", "text": "The <vocab>venture capital</vocab> world is unforgiving. Learn fast."}
        ],
        "vocab_ids": ["venture capital", "ROI", "equity", "investment", "return"]
    },
    {
        "chapter": 2,
        "level": 16,
        "title": "海外出差",
        "pre_story": [
            {"speaker": "narrator", "text": "你和陆景琛一起出差海外，异国他乡气氛微妙..."},
            {"speaker": "lujingchen", "text": "(看着窗外) International business is a different game."},
            {"speaker": "lujingchen", "text": "The <vocab>tariff</vocab> regulations change constantly."},
            {"speaker": "narrator", "text": "他难得展露脆弱一面，谈起了过往。"}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You handled the <vocab>import</vocab> negotiations flawlessly."},
            {"speaker": "lujingchen", "text": "International markets suit you."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>export</vocab> deal went through. Good work."},
            {"speaker": "lujingchen", "text": "But you need to understand <vocab>tariff</vocab> laws better."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You survived the trip. That's the best I can say."},
            {"speaker": "lujingchen", "text": "International trade requires more preparation."}
        ],
        "vocab_ids": ["tariff", "import", "export", "market", "globalization"]
    },
    {
        "chapter": 2,
        "level": 17,
        "title": "背叛",
        "pre_story": [
            {"speaker": "narrator", "text": "最信任的人突然叛变，公司陷入巨大危机..."},
            {"speaker": "lujingchen", "text": "(冷笑) Loyalty has a price."},
            {"speaker": "lujingchen", "text": "I just didn't expect his to be so cheap."},
            {"speaker": "lujingchen", "text": "We need to assess the <vocab>risk</vocab> and implement <vocab>contingency</vocab> plans."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "Your <vocab>risk</vocab> assessment was spot on."},
            {"speaker": "lujingchen", "text": "We're prepared because of you."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You identified the <vocab>insurance</vocab> gaps. Good."},
            {"speaker": "lujingchen", "text": "But the <vocab>contingency</vocab> plan needs more depth."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You saw it coming, but not soon enough."},
            {"speaker": "lujingchen", "text": "<vocab>Risk</vocab> management is about anticipation, not reaction."}
        ],
        "vocab_ids": ["risk", "contingency", "insurance", "threat", "weakness"]
    },
    {
        "chapter": 2,
        "level": 18,
        "title": "反击计划",
        "pre_story": [
            {"speaker": "narrator", "text": "陆景琛策划反击，你被任命为核心成员..."},
            {"speaker": "lujingchen", "text": "I need someone I can trust. That someone is you."},
            {"speaker": "lujingchen", "text": "We're going to <vocab>diversify</vocab> and <vocab>streamline</vocab>."},
            {"speaker": "lujingchen", "text": "This is our chance to strike back."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>strategy</vocab> worked perfectly. Outstanding."},
            {"speaker": "lujingchen", "text": "You're proving to be indispensable."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>benchmark</vocab> analysis was solid."},
            {"speaker": "lujingchen", "text": "Our <vocab>strategy</vocab> is sound."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "The plan worked, but it was messy."},
            {"speaker": "lujingchen", "text": "<vocab>Streamline</vocab> the process next time."}
        ],
        "vocab_ids": ["benchmark", "diversify", "streamline", "strategy", "tactic"]
    },
    {
        "chapter": 2,
        "level": 19,
        "title": "董事会",
        "pre_story": [
            {"speaker": "narrator", "text": "关键的董事会投票即将开始，气氛紧张到极点..."},
            {"speaker": "lujingchen", "text": "(看向你) You're here because I trust your judgment."},
            {"speaker": "lujingchen", "text": "The <vocab>board</vocab> needs to see our vision."},
            {"speaker": "lujingchen", "text": "We need the <vocab>shareholder</vocab> votes."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You swayed the <vocab>board</vocab>. Masterful."},
            {"speaker": "lujingchen", "text": "The <vocab>dividend</vocab> proposal passed because of you."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You held your own in front of the <vocab>board</vocab>. Good."},
            {"speaker": "lujingchen", "text": "The <vocab>shareholder</vocab> support is solid."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You survived the vote, but just barely."},
            {"speaker": "lujingchen", "text": "The <vocab>board</vocab> needs more convincing next time."}
        ],
        "vocab_ids": ["board", "shareholder", "dividend", "vote", "resolution"]
    },
    {
        "chapter": 2,
        "level": 20,
        "title": "暗涌再起",
        "pre_story": [
            {"speaker": "narrator", "text": "危机暂时解除，但新的威胁正在酝酿..."},
            {"speaker": "lujingchen", "text": "(握住你的手) Stay with me. This isn't over."},
            {"speaker": "lujingchen", "text": "The <vocab>turnaround</vocab> is complete, but the war continues."},
            {"speaker": "lujingchen", "text": "We need <vocab>synergy</vocab> now more than ever."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>restructuring</vocab> was a success. Excellent work."},
            {"speaker": "lujingchen", "text": "You're not just an employee anymore. You're my partner."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>turnaround</vocab> worked. Good progress."},
            {"speaker": "lujingchen", "text": "The <vocab>synergy</vocab> is starting to show."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We survived, but the <vocab>restructuring</vocab> was messy."},
            {"speaker": "lujingchen", "text": "We need more <vocab>synergy</vocab> moving forward."}
        ],
        "vocab_ids": ["turnaround", "restructuring", "synergy", "strategy", "vision"]
    },
    {
        "chapter": 3,
        "level": 21,
        "title": "全球布局",
        "pre_story": [
            {"speaker": "narrator", "text": "陆景琛启动全球化战略，你已是他的左膀右臂..."},
            {"speaker": "lujingchen", "text": "The world is our playground now."},
            {"speaker": "lujingchen", "text": "We're building a <vocab>conglomerate</vocab> that spans continents."},
            {"speaker": "lujingchen", "text": "<vocab>Globalization</vocab> isn't an option. It's our destiny."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>consortium</vocab> deal is sealed. Magnificent."},
            {"speaker": "lujingchen", "text": "You're a natural at international business."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>globalization</vocab> strategy is on track. Good."},
            {"speaker": "lujingchen", "text": "The <vocab>conglomerate</vocab> is taking shape."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We're moving forward, but slowly."},
            {"speaker": "lujingchen", "text": "<vocab>Globalization</vocab> requires more aggressive action."}
        ],
        "vocab_ids": ["globalization", "conglomerate", "consortium", "market", "international"]
    },
    {
        "chapter": 3,
        "level": 22,
        "title": "资本博弈",
        "pre_story": [
            {"speaker": "narrator", "text": "华尔街资本突然介入，局势变得更加复杂..."},
            {"speaker": "lujingchen", "text": "Wall Street thinks they can play with us? Let them try."},
            {"speaker": "lujingchen", "text": "We'll use their own <vocab>leverage</vocab> against them."},
            {"speaker": "lujingchen", "text": "The <vocab>derivative</vocab> markets are our battlefield now."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>arbitrage</vocab> play was brilliant. Perfect execution."},
            {"speaker": "lujingchen", "text": "You're a force to be reckoned with in finance."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>leverage</vocab> strategy worked. Good."},
            {"speaker": "lujingchen", "text": "But we need to watch the <vocab>derivative</vocab> exposure."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We won this round, but it was close."},
            {"speaker": "lujingchen", "text": "<vocab>Leverage</vocab> is a double-edged sword. Use it wisely."}
        ],
        "vocab_ids": ["leverage", "derivative", "arbitrage", "investment", "return"]
    },
    {
        "chapter": 3,
        "level": 23,
        "title": "信任危机",
        "pre_story": [
            {"speaker": "narrator", "text": "外界开始质疑你和陆景琛的关系，舆论压力剧增..."},
            {"speaker": "lujingchen", "text": "(握住你的手) Let them talk. We know the truth."},
            {"speaker": "lujingchen", "text": "<vocab>Transparency</vocab> is our best defense."},
            {"speaker": "lujingchen", "text": "Our <vocab>accountability</vocab> speaks for itself."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "You handled the crisis with <vocab>integrity</vocab>. Beautiful."},
            {"speaker": "lujingchen", "text": "The public sees the truth now."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>transparency</vocab> campaign worked. Good."},
            {"speaker": "lujingchen", "text": "Our <vocab>compliance</vocab> record speaks for itself."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "The storm passed, but trust was damaged."},
            {"speaker": "lujingchen", "text": "<vocab>Accountability</vocab> requires constant effort."}
        ],
        "vocab_ids": ["transparency", "accountability", "compliance", "integrity", "reputation"]
    },
    {
        "chapter": 3,
        "level": 24,
        "title": "终极谈判",
        "pre_story": [
            {"speaker": "narrator", "text": "最后一场决定命运的谈判即将开始，对手空前强大..."},
            {"speaker": "lujingchen", "text": "(看向你) This is it. The final battle."},
            {"speaker": "lujingchen", "text": "We'll use <vocab>arbitration</vocab> if we have to."},
            {"speaker": "lujingchen", "text": "But we won't make a single unnecessary <vocab>concession</vocab>."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>procurement</vocab> deal is ours. Outstanding."},
            {"speaker": "lujingchen", "text": "You negotiated like a master today."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>arbitration</vocab> avoided. Good work."},
            {"speaker": "lujingchen", "text": "Our <vocab>concession</vocab> was minimal."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We got the deal, but we gave too much."},
            {"speaker": "lujingchen", "text": "<vocab>Concession</vocab> is a last resort, not a strategy."}
        ],
        "vocab_ids": ["arbitration", "concession", "procurement", "negotiate", "bargain"]
    },
    {
        "chapter": 3,
        "level": 25,
        "title": "内部改革",
        "pre_story": [
            {"speaker": "narrator", "text": "陆景琛大刀阔斧改革公司，阻力重重..."},
            {"speaker": "lujingchen", "text": "Change is inevitable. Resistance is expected."},
            {"speaker": "lujingchen", "text": "We're going to <vocab>restructure</vocab> and <vocab>divestiture</vocab>."},
            {"speaker": "lujingchen", "text": "Some will fight it. Let them."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>restructure</vocab> was executed perfectly."},
            {"speaker": "lujingchen", "text": "You turned resistance into momentum."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>amortize</vocab> plan is in place. Good."},
            {"speaker": "lujingchen", "text": "The <vocab>divestiture</vocab> is proceeding smoothly."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "The reform is happening, but too slowly."},
            {"speaker": "lujingchen", "text": "<vocab>Restructure</vocab> requires decisive action."}
        ],
        "vocab_ids": ["restructure", "amortize", "divestiture", "streamline", "strategy"]
    },
    {
        "chapter": 3,
        "level": 26,
        "title": "情感抉择",
        "pre_story": [
            {"speaker": "narrator", "text": "商业与感情的十字路口，陆景琛第一次说出真心话..."},
            {"speaker": "lujingchen", "text": "(眼神真挚) I don't do this often. But you need to know."},
            {"speaker": "lujingchen", "text": "This isn't just business. It's... personal."},
            {"speaker": "lujingchen", "text": "Your <vocab>commitment</vocab> means everything to me."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "(微笑) You chose us. That's all that matters."},
            {"speaker": "lujingchen", "text": "Our <vocab>vision</vocab> together is unstoppable. 💍"}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "You made your choice. I respect that."},
            {"speaker": "lujingchen", "text": "Our <vocab>commitment</vocab> will be tested, but it will hold."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You need time. I'll wait."},
            {"speaker": "lujingchen", "text": "<vocab>Integrity</vocab> means being true to yourself first."}
        ],
        "vocab_ids": ["commitment", "integrity", "vision", "trust", "loyalty"]
    },
    {
        "chapter": 3,
        "level": 27,
        "title": "最后的危机",
        "pre_story": [
            {"speaker": "narrator", "text": "最大危机来临，一切似乎要崩塌..."},
            {"speaker": "lujingchen", "text": "(冷静) This is not the end. Not yet."},
            {"speaker": "lujingchen", "text": "We've faced <vocab>catastrophe</vocab> before. We'll survive this too."},
            {"speaker": "lujingchen", "text": "No <vocab>insolvency</vocab> on my watch."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "We avoided <vocab>liquidation</vocab>. Against all odds."},
            {"speaker": "lujingchen", "text": "You saved this company. I'll never forget that."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "We weathered the storm. Good work."},
            {"speaker": "lujingchen", "text": "The <vocab>catastrophe</vocab> was contained."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We survived, but just barely."},
            {"speaker": "lujingchen", "text": "<vocab>Insolvency</vocab> was a hair's breadth away. Never again."}
        ],
        "vocab_ids": ["catastrophe", "insolvency", "liquidation", "crisis", "risk"]
    },
    {
        "chapter": 3,
        "level": 28,
        "title": "绝地反击",
        "pre_story": [
            {"speaker": "narrator", "text": "你和陆景琛联手，上演商业史上的逆转..."},
            {"speaker": "lujingchen", "text": "Now we fight back. With everything we have."},
            {"speaker": "lujingchen", "text": "The <vocab>capitalization</vocab> strategy is our weapon."},
            {"speaker": "lujingchen", "text": "We'll <vocab>recapitalize</vocab> and strike."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>turnaround</vocab> is complete. Magnificent."},
            {"speaker": "lujingchen", "text": "Together, we're unstoppable."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>capitalization</vocab> worked. Good."},
            {"speaker": "lujingchen", "text": "We've turned the tide."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "We won, but it was costly."},
            {"speaker": "lujingchen", "text": "<vocab>Recapitalize</vocab> wisely next time."}
        ],
        "vocab_ids": ["capitalization", "recapitalize", "turnaround", "strategy", "leverage"]
    },
    {
        "chapter": 3,
        "level": 29,
        "title": "真相大白",
        "pre_story": [
            {"speaker": "narrator", "text": "一切谜团解开，陆景琛的秘密终于曝光..."},
            {"speaker": "lujingchen", "text": "It's time you knew the truth."},
            {"speaker": "lujingchen", "text": "The <vocab>disclosure</vocab> has been a long time coming."},
            {"speaker": "lujingchen", "text": "Everything I did... was for you."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "The <vocab>proprietary</vocab> information is yours now."},
            {"speaker": "lujingchen", "text": "You deserve to know everything. Always have."}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The <vocab>disclosure</vocab> is complete. Good."},
            {"speaker": "lujingchen", "text": "We've been through <vocab>due diligence</vocab> together."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "You know the truth now. It wasn't easy."},
            {"speaker": "lujingchen", "text": "<vocab>Proprietary</vocab> trust is earned, not given."}
        ],
        "vocab_ids": ["disclosure", "proprietary", "due diligence", "confidentiality", "truth"]
    },
    {
        "chapter": 3,
        "level": 30,
        "title": "新的开始",
        "pre_story": [
            {"speaker": "narrator", "text": "终章。陆景琛站在顶楼俯瞰城市..."},
            {"speaker": "lujingchen", "text": "(握住你的手) Look at what we've built."},
            {"speaker": "lujingchen", "text": "This empire is ours now."},
            {"speaker": "lujingchen", "text": "Our <vocab>prosperity</vocab} is just beginning."}
        ],
        "post_story_stars3": [
            {"speaker": "lujingchen", "text": "(微笑) You've come a long way from that first day."},
            {"speaker": "lujingchen", "text": "Our <vocab>legacy</vocab} will endure. Together."},
            {"speaker": "lujingchen", "text": "<vocab>Sustainability</vocab} isn't just business. It's us. 🌟"}
        ],
        "post_story_stars2": [
            {"speaker": "lujingchen", "text": "The future is ours. Congratulations."},
            {"speaker": "lujingchen", "text": "Our <vocab>prosperity</vocab} is assured."}
        ],
        "post_story_stars1": [
            {"speaker": "lujingchen", "text": "This is just the beginning."},
            {"speaker": "lujingchen", "text": "<vocab>Legacy</vocab} is built over generations. We've started ours."}
        ],
        "vocab_ids": ["sustainability", "legacy", "prosperity", "vision", "future"]
    }
];
